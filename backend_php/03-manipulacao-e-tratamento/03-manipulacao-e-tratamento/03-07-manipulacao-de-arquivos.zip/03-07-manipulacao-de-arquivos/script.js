
var $phoneInput = document.getElementById('phone'); 
$phoneInput.mask('(00) 00000-0000');
console.log($phoneInput);
